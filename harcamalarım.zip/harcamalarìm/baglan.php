<?php
    $host      = "127.0.0.1";
    $kullanici = "root";
    $sifre     = "";
    $db        ="AYLIK_HARCAMA";

$mysqli = new mysqli($host, $kullanici, $sifre, $db);
$result = $mysqli->query("CREATE TABLE Harcama
(
HarcamaID int,
MagazaAdi varchar(255),
Tarih varchar(255),
Odeme varchar(255)
);");

?>