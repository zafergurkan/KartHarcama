<?php 

$magazaAdi = $_GET["magazaAdi"];
$tarih = $_GET["tarih"];
$odeme = $_GET["odeme"];

require_once("baglan.php");

$sorgu = $mysqli->query("INSERT INTO harcama (MagazaAdi,Tarih,Odeme) VALUES ('$magazaAdi', '$tarih', '$odeme')");

if ($sorgu)
{
     echo "İşleminiz başarıyla gerçekleştirildi!";
}
else
{
     echo "HATA!!! Verileriniz eklenemedi...";
}




 ?>