<?php 

$ID = $_GET["ID"];

require_once("baglan.php");

$sorgu = $mysqli->query("DELETE FROM harcama WHERE HarcamaID='".$ID."'");

if ($sorgu)
{
     echo "İşleminiz başarıyla gerçekleştirildi!";
}
else
{
     echo "HATA!!! Verileriniz eklenemedi...";
}




 ?>